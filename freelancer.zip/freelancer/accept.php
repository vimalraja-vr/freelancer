<?php
session_start();
include 'dbconnect.php';
extract($_REQUEST);
$uname=$_SESSION['uname'];
$rdate=date("Y/m/d");
$sq="select * from job_post where id='$id'";
$qu=mysqli_query($con,$sq);
$rrow = mysqli_fetch_array($qu);
$name=$rrow['name'];
$projecttitle=$rrow['projecttitle'];
$delivery=$rrow['delivery'];
$cost=$rrow['cost'];
$description=$rrow['description'];

if(isset($btn)){

$ins="insert into freelancer_job (name,uname,projecttitle,delivery,cost,description,status,rdate)value('$name','$uname','$projecttitle','$delivery','$cost','$description','Accept Job','$rdate')";

$qry=mysqli_query($con, $ins);
if($qry)
{
?>
<script language="javascript">
window.location.href="acceptjob.php";
</script>
<?php
}
else{
    echo "error";
}
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include("include/title.php");?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
<?php include("include/homelink.php");?>
    <div class="hero-wrap js-fullheight" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
    <center>
      <div class="overlay"></div>
      <div class="container">
    		<div class="row d-md-flex justify-content-center">
    			<div class="col-md-6 half p-3 py-5 pl-md-5 ftco-animate heading-section heading-section-white">
    				<br><br>
    				<h2 class="mb-4">Freelancer Job Request</h2>
                    
    				<form method="POST" class="consultation">
	            <div class="">
	              <input type="text" class="form-control" name="name" placeholder="Job Poster Name" value="<?php echo $name;?>" >
	            </div>
	            
                <div class="">
	              <input type="text" class="form-control" name="projecttitle" placeholder="Project Title" value="<?php echo $projecttitle;?>">
	            </div>
                
                <div class="">
	              <input type="text" class="form-control" name="delivery" placeholder="Delivery Date" value="<?php echo $delivery;?>">
	            </div>
	            <div class="">
	              <input type="text" class="form-control" name="cost" placeholder="Cost Of Project" value="<?php echo $cost;?>">
	            </div>
                <div class="">
	              <input type="text" class="form-control" name="description" placeholder="Description" value="<?php echo $description;?>">
	            </div>
                <div class="">
	              <input type="submit" class="form-control" name="btn" value="submit">
	            </div>
                 <p><?php echo $msg; ?></div>

	            
	            
        
	          </form>
    			</div>
    		</div>
    	</div>
          	
          </div>
        </div>
      </div>
</center>
    </div>

    
		

		


    

    <?php include("include/footer.php");?>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>
