<?php
session_start();
include 'dbconnect.php';
extract($_REQUEST);
$rdate=date("Y/m/d");
$uname=$_SESSION['uname'];
$sq="select * from job_post where status='1'";
$qu=mysqli_query($con,$sq);

$sql="select * from job_post where status='1'";
if(isset($btn)){

$ins="insert into freelancer_job (id,name,uname,projecttitle,delivery,cost,description,status,rdate)value('$id','$name','$uname','$projecttitle','$delivery','$cost','$description','Accept Job','$rdate'))";

$qry=mysqli_query($con, $ins);
if($qry)
{
?>
<script language="javascript">
window.location.href="adminhome.php";
</script>
<?php
}
else{
    echo "error";
}
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title><?php include("include/title.php");?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
 
    
	  <nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
      <a class="navbar-brand" href="index.php"><?php include("include/title.php");?></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
               <li class="nav-item active"><a href="adminhome.php" class="nav-link">Accept Job</a></li>
               <li class="nav-item"><a href="myfile.php" class="nav-link">Project Upload</a></li>
               <li class="nav-item"><a href="transaction.php" class="nav-link">Transaction</a></li>
               <li class="nav-item"><a href="feed.php" class="nav-link">Feedback</a></li>
               <li class="nav-item"><a href="logout.php" class="nav-link">Logout</a></li>
	          
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    
    
    
    

    

		
		


    <div class="hero-wrap js-fullheight" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
    
      
      <div class="container">
       <div style="text-align: center;">
    		
    				<br><br><br><br>
            

    				<h2 class="text-white">Approve/Reject Jobpost</h2>
                    
            <form action="" method="post" enctype="multipart/form-data">

	            
                    <table class="table table-stripped">
                                <tr>
                                    <th class="text-info">S.No</th>
                                    <th class="text-info">Job Poster Name</th>
                                    <th class="text-info">Project Title</th>
                                    <th class="text-info">Delivery Time</th>
                                    <th class="text-info">Cost Of Project</th>
                                    <th class="text-info">File</th>
                                    <th class="text-info">Description</th>
									 <th class="text-info">Registered Date</th>
                                    <th class="text-info">Action</th>


                                </tr>
								<?php
		  $r = 0;
		  while($rrow = mysqli_fetch_assoc($qu)){
		  $r++;
          $name=$rrow['name'];
          $projecttitle=$rrow['projecttitle'];
          $delivery=$rrow['delivery'];
          $cost=$rrow['cost'];
          $description=$rrow['description'];
          $rdate=$rrow['rdate'];

		  ?>
          <tr>
            
          <td class="text-white"><?php echo $r; ?></td>
            
            <td class="text-white"><?php echo $name; ?></td>
            <td class="text-white"><?php echo $projecttitle; ?></td>
            <td class="text-white"><?php echo $delivery; ?></td>
            <td class="text-white"><?php echo $cost; ?></td>
            <td><a href="<?php echo $rrow['file']?>" target="_blank" download>Download</a> | <a href="<?php echo $rrow['file']?>"  target="_blank" view>View</a></td>
            <td class="text-white"><?php echo $rrow['description']; ?></td>
            <td class="text-white"><?php echo $rdate; ?></td>
            <td class="text-white"><a href="accept.php?id=<?php echo $rrow['id'];?>">Accept</a></td>

          </tr>
          
		  <?php 
		  }
		  ?>

        </table>
                                
							
							
                        
    
						</form>
					
    	</div>
    </div>
    </div>
     

    
    
    
    



    <?php include("include/footer.php");?>

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>