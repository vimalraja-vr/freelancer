<?php
session_start();
include 'dbconnect.php';
$uname=$_SESSION['uname'];
if(isset($_POST['reg'])){
    $otp=rand(1000,9999);
    
    $i="update fees set status='1',otp='$otp' where uname='$uname'";
	
    $qry=mysqli_query($con, $i);
	if($qry)
				{
				//header("location:payment.php");
                ?>
                <script language="javascript">
		alert("Paymment sent Successfully");
		window.location.href="payment.php";
		</script>
		<?php
		}
		else
		{
		$msg="Could not Registered";
		}
	
				}
    ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Lawyer</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  <nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
      <a class="navbar-brand" href="index.html">E-LAWYER <span>COMMUNICATION</span></a>

	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="page.php" class="nav-link">Case File Upload</a></li>
               <li class="nav-item active"><a href="payment.php" class="nav-link">Bill</a></li>
               <li class="nav-item"><a href="hearing_info.php" class="nav-link">Hearing Information</a></li>
               <li class="nav-item"><a href="logout.php" class="nav-link">Logout</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
      
    <!-- END nav -->
    
    <div class="hero-wrap js-fullheight" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
    <center>
      <div class="overlay"></div>
      <div class="container">
    		<div class="row d-md-flex justify-content-center">
    			<div class="col-md-6 half p-3 py-5 pl-md-5 ftco-animate heading-section heading-section-white">
    				<br><br>
    				<h2 class="mb-4">Bill Payment</h2>
                    
    				<form method="POST" class="consultation">
                <div class="">
	              <input type="text" class="form-control" name="cardno" placeholder="Card Number">
	            </div>
	            <div class="">
                <select name="bank" class="form-control">
                     <option value="0">Select Bank</option>
                     <option value="1">SBI</option>
                     <option value="2">Indian Bank</option>
                     <option value="3">IOB</option>
                     <option value="4">KVB</option>
                     <option value="5">LVB</option>
                     <option value="6">Canera</option>
                     <option value="7">CUB</option>
                        

                  </select>
	              
	            </div>
                <div class="">
                  <input type="text" class="form-control" name="month" placeholder="Month">
                  <input type="text" class="form-control" name="year" placeholder="Year">
              </div>
	            
                <div class="">
	              <input type="text" class="form-control" name="cvv" placeholder="CVV">
	            </div>
                
                
	            
                <div class="">
	              <input type="submit" class="form-control" name="reg" value="Pay">
	            </div>
                 <p><?php echo $msg; ?></div>

	            
	            
        
                 </form>
    			</div>
    		</div>
    	</div>
          	
          </div>
        </div>
      </div>
</center>
    </div>
	            


    
		

		


    

    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            <h2 class="logo"><a href="#">E-LAWYER <span>COMMUNICATION</span></a></h2>
              <p>Legal solutions for business and individual needs.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          
          
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Business Hours</h2>
              <div class="opening-hours">
              	<h4>Opening Days:</h4>
              	<p class="pl-3">
              		<span>Monday – Friday : 9am to 8pm</span>
              		<span>Saturday : 9am to 3pm</span>
              	</p>
              	<h4>Vacations:</h4>
              	<p class="pl-3">
              		<span>All Sunday Days</span>
              		<span>All Official Holidays</span>
              	</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="icon-heart color-danger" aria-hidden="true"></i> by <a href="Law Firm Agency"> Lawyer</a>
  <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
          </div>
        </div>
      </div>
    </footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>