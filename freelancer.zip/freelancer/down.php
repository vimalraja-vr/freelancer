<?php  
session_start();
error_reporting(0);
include('dbconnect.php');
$uname=$_SESSION['uname'];


?>

<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Search Indian Ticket - Park Ticket Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
</head>

<body>
    
    <!-- page container area start -->
    <div class="page-container">
        <!-- sidebar menu area start -->
        
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <!-- header area end -->
            <!-- page title area start -->
            <!-- page title area end -->
            <div class="main-content-inner">
                <div class="row">
                    <!-- data table start -->
                    <div class="col-12 mt-5">
                        <div class="card">
                            <div class="card-body">
                                <form id="basic-form" method="post">
                                <div class="form-group">
                                    <label>Search by Ticket ID</label>
                                    <input id="searchdata" type="text" name="searchdata" required="true" class="form-control" placeholder="Ticket ID"></div>
                                
                                <br>
                                <button type="submit" class="btn btn-primary" name="search" id="submit">Search</button>
                            </form>  
                            <?php
if(isset($_POST['search']))
{ 

$sdata=$_POST['searchdata'];
  ?>
  <h4 align="center">Result against "<?php echo $sdata;?>" keyword </h4>  
                                <div class="data-tables">
                                  <table class="table text-center">
                                        <thead class="bg-light text-capitalize">
                                            <tr>
                                                <th>S.NO</th>
                                                <th>File</th>
                                                <th>description</th>
												<th>Rdate</th>
                                                
                                            </tr>
                                        </thead>
                                        <?php
$i="select * from myfile  where description like '$sdata%'";
     $qry=mysqli_query($con, $i);
   if(mysqli_num_rows($qry)>0){

$cnt=1;
while ($row=mysqli_fetch_array($qry)) {

?>
                                        <tbody>
          <tr data-expanded="true">
            <td><?php echo $cnt;?></td>
              
                 <td><?php  echo $row['file'];?></td>
                  <td><?php  echo $row['description'];?></td>
				  <td><?php  echo $row['rdate'];?></td>
                  
                </tr>
                 <?php 
$cnt=$cnt+1;} } else { ?>
  <tr>
    <td colspan="8"> No record found against this search</td>

  </tr>
   

<?php }} ?>
 </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- data table end -->
                   
                    
                </div>
            </div>
        </div>
        <!-- main content area end -->
        <!-- footer area start-->
       
        <!-- footer area end-->
    </div>
    <!-- page container area end -->
    
    
    <!-- jquery latest version -->
   
</body>

</html>
