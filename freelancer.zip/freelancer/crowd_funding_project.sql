-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 09, 2025 at 09:18 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `crowd_funding_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `uname` varchar(20) NOT NULL,
  `password` varchar(29) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`uname`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(40) NOT NULL,
  `uname` varchar(40) NOT NULL,
  `feed` varchar(40) NOT NULL,
  `rdate` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `fees`
--

CREATE TABLE `fees` (
  `uname` varchar(34) NOT NULL,
  `freelancer` varchar(40) NOT NULL,
  `amount` varchar(34) NOT NULL,
  `status` varchar(20) NOT NULL,
  `rdate` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fees`
--


-- --------------------------------------------------------

--
-- Table structure for table `freelancer_job`
--

CREATE TABLE `freelancer_job` (
  `id` int(40) NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  `uname` varchar(40) NOT NULL,
  `projecttitle` varchar(40) NOT NULL,
  `delivery` varchar(40) NOT NULL,
  `cost` varchar(40) NOT NULL,
  `description` varchar(100) NOT NULL,
  `status` varchar(40) NOT NULL,
  `rdate` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `freelancer_job`
--


-- --------------------------------------------------------

--
-- Table structure for table `job_post`
--

CREATE TABLE `job_post` (
  `id` int(40) NOT NULL auto_increment,
  `name` varchar(20) NOT NULL,
  `projecttitle` varchar(40) NOT NULL,
  `delivery` varchar(40) NOT NULL,
  `cost` varchar(40) NOT NULL,
  `file` varchar(40) NOT NULL,
  `description` varchar(40) NOT NULL,
  `rdate` varchar(40) NOT NULL,
  `status` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `job_post`
--


-- --------------------------------------------------------

--
-- Table structure for table `journal_upload`
--

CREATE TABLE `journal_upload` (
  `id` int(70) NOT NULL auto_increment,
  `caseno` varchar(50) NOT NULL,
  `file` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `rdate` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `journal_upload`
--


-- --------------------------------------------------------

--
-- Table structure for table `myfile`
--

CREATE TABLE `myfile` (
  `id` int(80) NOT NULL auto_increment,
  `file` varchar(100) NOT NULL,
  `link` varchar(255) NOT NULL,
  `uname` varchar(40) NOT NULL,
  `jobposter` varchar(40) NOT NULL,
  `description` varchar(100) NOT NULL,
  `rdate` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `myfile`
--


-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(25) NOT NULL,
  `mobile` varchar(25) NOT NULL,
  `city` varchar(25) NOT NULL,
  `uname` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `rdate` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `register`
--


-- --------------------------------------------------------

--
-- Table structure for table `sregister`
--

CREATE TABLE `sregister` (
  `id` int(40) NOT NULL auto_increment,
  `name` varchar(40) NOT NULL,
  `type` varchar(40) NOT NULL,
  `mobile` varchar(40) NOT NULL,
  `city` varchar(40) NOT NULL,
  `uname` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `rdate` varchar(40) NOT NULL,
  `status` varchar(40) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sregister`
--

