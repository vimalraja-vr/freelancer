-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 03, 2022 at 05:13 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `agrirental_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL auto_increment,
  `permission` varchar(255) NOT NULL,
  `createuser` varchar(255) default NULL,
  `deleteuser` varchar(255) default NULL,
  `createbid` varchar(255) default NULL,
  `updatebid` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `permission`, `createuser`, `deleteuser`, `createbid`, `updatebid`) VALUES
(1, 'Superuser', '1', '1', '1', '1'),
(2, 'Admin', '1', NULL, '1', '1'),
(3, 'User', NULL, NULL, '1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `ID` int(10) NOT NULL auto_increment,
  `Staffid` int(10) default NULL,
  `AdminName` varchar(120) default NULL,
  `UserName` varchar(120) default NULL,
  `FirstName` varchar(255) default NULL,
  `LastName` varchar(255) default NULL,
  `MobileNumber` bigint(10) default NULL,
  `Email` varchar(200) default NULL,
  `Status` int(11) NOT NULL default '1',
  `Photo` varchar(255) NOT NULL default 'avatar15.jpg',
  `Password` varchar(120) default NULL,
  `AdminRegdate` timestamp NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`ID`, `Staffid`, `AdminName`, `UserName`, `FirstName`, `LastName`, `MobileNumber`, `Email`, `Status`, `Photo`, `Password`, `AdminRegdate`) VALUES
(2, 1005, 'Admin', 'admin', 'John', 'Smith', 770546590, 'admin@gmail.com', 1, '269113697_b717571d5e_n.jpg', '21232f297a57a5a743894a0e4a801fc3', '2021-06-21 10:18:39'),
(9, 1234, 'Admin', 'tom', 'Agaba', 'tom', 757537271, 'tom@gmail.com', 1, 'pic_3.jpg', '25d55ad283aa400af464c76d713c07ad', '2021-06-21 07:08:48'),
(29, 0, 'User', 'gerald', 'Gerald', 'Brain', 770546590, 'brain@gmail.com', 1, 'avatar15.jpg', '81dc9bdb52d04dc20036dbd8313ed055', '2021-07-24 10:40:34');

-- --------------------------------------------------------

--
-- Table structure for table `tblbooking`
--

CREATE TABLE `tblbooking` (
  `id` int(11) NOT NULL auto_increment,
  `BookingNumber` bigint(12) default NULL,
  `userEmail` varchar(100) default NULL,
  `VehicleId` int(11) default NULL,
  `FromDate` varchar(20) default NULL,
  `ToDate` varchar(20) default NULL,
  `message` varchar(255) default NULL,
  `Status` int(11) default NULL,
  `PostingDate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `LastUpdationDate` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tblbooking`
--

INSERT INTO `tblbooking` (`id`, `BookingNumber`, `userEmail`, `VehicleId`, `FromDate`, `ToDate`, `message`, `Status`, `PostingDate`, `LastUpdationDate`) VALUES
(8, 544731172, 'taju@gmail.com', 11, '2022-05-20', '2022-05-24', 'For Farming', 1, '2022-05-20 18:34:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblbrands`
--

CREATE TABLE `tblbrands` (
  `id` int(11) NOT NULL auto_increment,
  `BrandName` varchar(120) NOT NULL,
  `CreationDate` timestamp NULL default NULL,
  `UpdationDate` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `tblbrands`
--

INSERT INTO `tblbrands` (`id`, `BrandName`, `CreationDate`, `UpdationDate`) VALUES
(9, 'Tractor', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblcompany`
--

CREATE TABLE `tblcompany` (
  `id` int(11) NOT NULL auto_increment,
  `regno` varchar(255) default NULL,
  `companyname` varchar(255) default NULL,
  `companyemail` varchar(255) default NULL,
  `country` varchar(255) default NULL,
  `companyphone` int(10) NOT NULL,
  `companyaddress` varchar(255) NOT NULL,
  `companylogo` varchar(255) NOT NULL default 'avatar15.jpg',
  `status` varchar(255) NOT NULL default '0',
  `creationdate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblcompany`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblorders`
--

CREATE TABLE `tblorders` (
  `id` int(11) NOT NULL auto_increment,
  `ProductId` int(11) default NULL,
  `Quantity` int(11) default NULL,
  `InvoiceNumber` int(11) default NULL,
  `CustomerName` varchar(150) default NULL,
  `CustomerContactNo` bigint(12) default NULL,
  `PaymentMode` varchar(100) default NULL,
  `InvoiceGenDate` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblorders`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblpay`
--

CREATE TABLE `tblpay` (
  `FullName` varchar(50) NOT NULL,
  `ContactNo` varchar(50) NOT NULL,
  `Details` varchar(50) NOT NULL,
  `Account` varchar(50) NOT NULL,
  `Amount` varchar(50) NOT NULL,
  `EmailId` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblpay`
--

INSERT INTO `tblpay` (`FullName`, `ContactNo`, `Details`, `Account`, `Amount`, `EmailId`) VALUES
('Taju', '9790530960', 'For Tractor', '3454675678', '6000', 'taju@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubscribers`
--

CREATE TABLE `tblsubscribers` (
  `id` int(11) NOT NULL auto_increment,
  `SubscriberEmail` varchar(120) default NULL,
  `PostingDate` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tblsubscribers`
--


-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(11) NOT NULL auto_increment,
  `FullName` varchar(120) default NULL,
  `EmailId` varchar(100) default NULL,
  `Password` varchar(100) default NULL,
  `ContactNo` char(11) default NULL,
  `dob` varchar(100) default NULL,
  `Address` varchar(255) default NULL,
  `City` varchar(100) default NULL,
  `Country` varchar(100) default NULL,
  `RegDate` timestamp NULL default NULL,
  `UpdationDate` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `EmailId` (`EmailId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `FullName`, `EmailId`, `Password`, `ContactNo`, `dob`, `Address`, `City`, `Country`, `RegDate`, `UpdationDate`) VALUES
(5, 'Taju', 'taju@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '9790530960', NULL, NULL, NULL, NULL, '2022-05-20 18:30:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tblvehicles`
--

CREATE TABLE `tblvehicles` (
  `id` int(11) NOT NULL auto_increment,
  `VehiclesTitle` varchar(150) default NULL,
  `VehiclesBrand` int(11) default NULL,
  `VehiclesOverview` longtext,
  `PricePerDay` int(11) default NULL,
  `FuelType` varchar(100) default NULL,
  `ModelYear` int(6) default NULL,
  `SeatingCapacity` int(11) default NULL,
  `Vimage1` varchar(120) default NULL,
  `Vimage2` varchar(120) default NULL,
  `Vimage3` varchar(120) default NULL,
  `Vimage4` varchar(120) default NULL,
  `Vimage5` varchar(120) default NULL,
  `AirConditioner` int(11) default NULL,
  `PowerDoorLocks` int(11) default NULL,
  `AntiLockBrakingSystem` int(11) default NULL,
  `BrakeAssist` int(11) default NULL,
  `PowerSteering` int(11) default NULL,
  `DriverAirbag` int(11) default NULL,
  `PassengerAirbag` int(11) default NULL,
  `PowerWindows` int(11) default NULL,
  `CDPlayer` int(11) default NULL,
  `CentralLocking` int(11) default NULL,
  `CrashSensor` int(11) default NULL,
  `LeatherSeats` int(11) default NULL,
  `RegDate` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `UpdationDate` timestamp NULL default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tblvehicles`
--

INSERT INTO `tblvehicles` (`id`, `VehiclesTitle`, `VehiclesBrand`, `VehiclesOverview`, `PricePerDay`, `FuelType`, `ModelYear`, `SeatingCapacity`, `Vimage1`, `Vimage2`, `Vimage3`, `Vimage4`, `Vimage5`, `AirConditioner`, `PowerDoorLocks`, `AntiLockBrakingSystem`, `BrakeAssist`, `PowerSteering`, `DriverAirbag`, `PassengerAirbag`, `PowerWindows`, `CDPlayer`, `CentralLocking`, `CrashSensor`, `LeatherSeats`, `RegDate`, `UpdationDate`) VALUES
(11, 'Blue Tractor', 9, 'Usage For Agriculture Faming', 700, 'Diesel', 2019, 1, '1.png', '2.jpg', '3.jpg', '6.jpg', '7.jpg', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-05-21 20:22:41', NULL);
